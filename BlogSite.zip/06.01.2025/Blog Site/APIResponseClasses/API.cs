﻿namespace Blog_Site.APIResponseClasses
{
    public class API
    {
        public API()
        {
        }
    }
}
