﻿using Blog_Site.Entities;

namespace Blog_Site.Repositories
{
    public class PostRepository : BaseRepository<Post>
    {

    }
}
