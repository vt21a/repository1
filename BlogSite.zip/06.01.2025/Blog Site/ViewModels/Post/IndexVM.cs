﻿namespace Blog_Site.ViewModels.Post
{
    public class IndexVM
    {
    }
}
